﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class AddProduct : Form
    {
       

        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public AddProduct()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO ProductList (ItemID, ItemName, Stock) VALUES ('" +
                         txtItemid.Text + "', '" + txtname.Text + "', '" + txtstock.Text + "')";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    int cnt = cmd.ExecuteNonQuery();
                    if (cnt == 1)
                    {
                        MessageBox.Show("Item Added");
                        txtItemid.Text = "";
                        txtname.Text = "";
                        txtstock.Text = "";
                    }
                    else
                    {
                        MessageBox.Show("Something Error");
                    }
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
