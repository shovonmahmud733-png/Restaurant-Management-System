﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace RestaurantManagementSystems
{
    public partial class Admin : Form
    {
        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public Admin()
        {
            InitializeComponent();
            PopulateGridView();
        }

        private DataTable ExecuteQuery(string sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            con.Open();
            adapter.Fill(dt);
            con.Close();
            adapter.Dispose();
            cmd.Dispose();
            con.Dispose();
            return dt;
        }

        private int ExecuteDMLQuery(string sql)
        {
            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(sql, con);
            con.Open();
            int result = cmd.ExecuteNonQuery();
            con.Close();
            cmd.Dispose();
            con.Dispose();
            return result;
        }

        private void PopulateGridView(string sql = "SELECT * FROM [User]")
        {
            DataTable dt = ExecuteQuery(sql);
            dgvMenuGridView.AutoGenerateColumns = false;
            dgvMenuGridView.DataSource = dt;
        }

        private void ShowDetails()
        {
            PopulateGridView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ShowDetails();
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            AdminAddUsers addForm = new AdminAddUsers();
            addForm.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvMenuGridView.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Please Select a Row First!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            string id = dgvMenuGridView.CurrentRow.Cells[0].Value.ToString();
            string pass = dgvMenuGridView.CurrentRow.Cells[1].Value.ToString();
            string role = dgvMenuGridView.CurrentRow.Cells[2].Value.ToString();
            UpdateUser updateForm = new UpdateUser(id, pass, role);
            updateForm.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are You Sure You Want To Delete this User?", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
                return;
            string id = dgvMenuGridView.CurrentRow.Cells[0].Value.ToString();
            string sql = "DELETE FROM [User] WHERE UserID = '" + id + "';";
            int count = ExecuteDMLQuery(sql);
            if (count == 1)
                MessageBox.Show("User Deleted");
            else
                MessageBox.Show("Something Error");
            PopulateGridView();
        }

        private void btnMenu_Click(object sender, EventArgs e)
        {
            MENU menuForm = new MENU();
            this.Hide();
            menuForm.Show();
            
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Login loginForm = new Login();
            this.Hide();
            loginForm.Show();
            
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            Product productForm = new Product("Admin");
            this.Hide();
            productForm.Show();
            
        }
    }
}