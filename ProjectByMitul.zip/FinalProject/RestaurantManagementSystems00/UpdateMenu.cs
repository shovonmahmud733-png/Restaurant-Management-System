﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class UpdateMenu : Form
    {
        
        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public UpdateMenu()
        {
            InitializeComponent();
        }

        public UpdateMenu(string itemid, string itemname, string price, string quan)
        {
            InitializeComponent();
            this.txtitemID.Text = itemid;
            this.txtItemName.Text = itemname;
            this.txtPrice.Text = price;
            this.txtStock.Text = quan;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "UPDATE [Menu] SET ItemName = @itemName, Price = @price, Stock = @stock WHERE ItemID = @itemId";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@itemId", txtitemID.Text);
                        cmd.Parameters.AddWithValue("@itemName", txtItemName.Text);
                        cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                        cmd.Parameters.AddWithValue("@stock", txtStock.Text);

                        int cnt = cmd.ExecuteNonQuery();
                        if (cnt == 1)
                            MessageBox.Show("Menu Updated");
                        else
                            MessageBox.Show("Menu Not Updated");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        


    }
}
