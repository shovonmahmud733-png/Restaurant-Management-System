﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class UpdateUser : Form
    {
      
        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public UpdateUser()
        {
            InitializeComponent();
        }

        public UpdateUser(string userId, string password, string role)
        {
            InitializeComponent();
            this.txtUserID.Text = userId;
            this.txtPassword.Text = password;
            this.txtRole.Text = role;
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "UPDATE [User] SET Password = @password, Role = @role WHERE UserID = @userId";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@userId", txtUserID.Text);
                        cmd.Parameters.AddWithValue("@password", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@role", txtRole.Text);

                        int cnt = cmd.ExecuteNonQuery();
                        if (cnt == 1)
                            MessageBox.Show("User Updated");
                        else
                            MessageBox.Show("User Not Updated");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating user: " + ex.Message);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.Close();
           // Admin admin = new Admin();
            //admin.Show();
        }

        
    }
}
