﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class Cart : Form
    {
       
            private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";
            public double subTotal;
            public double vat = 1.075;

            public Cart()
            {
                InitializeComponent();
            }

            public Cart(string id, string name, double price, int quan) : this()
            {
                Addincart(id, name, price, quan);
            }

            public void Addincart(string id, string name, double price, int quan)
            {
                double Total = price * quan;
                subTotal = subTotal + Total;
                this.dgvMenuGridView.Rows.Add(name, price, quan, Total, id);
                this.txtVat.Text = "7.5%";
                double final = subTotal * vat;
                this.txtTotal.Text = final.ToString();
                this.txtSubTotal.Text = subTotal.ToString();
            }

            private void Cart_Load(object sender, EventArgs e)
            {
            }

            private void lblSubTotal_Click(object sender, EventArgs e)
            {
            }

            private void btnAddItem_Click(object sender, EventArgs e)
            {
                Form admin = new MenuList();
                admin.Show();
                this.Hide();
            }

            private void btnDeleteItem_Click(object sender, EventArgs e)
            {
                this.dgvMenuGridView.Rows.Clear();
                this.txtSubTotal.Text = "";
                this.txtTotal.Text = "";
                this.txtVat.Text = "";
                this.Close();
            }

            private void btnUpdateItem_Click(object sender, EventArgs e)
            {
                if (dgvMenuGridView.SelectedRows.Count <= 0)
                {
                    MessageBox.Show("Please Select a Row first");
                    return;
                }
                btnsaveQuan.Visible = true;
                txtUpdateQuan.Visible = true;
            }

            private void btnsaveQuan_Click(object sender, EventArgs e)
            {
                if (dgvMenuGridView.SelectedRows.Count <= 0)
                {
                    MessageBox.Show("Please select a row first!");
                    return;
                }

                DataGridViewRow selectedRow = dgvMenuGridView.SelectedRows[0];
                double price = Convert.ToDouble(selectedRow.Cells[1].Value);
                int newQuantity = Convert.ToInt32(txtUpdateQuan.Text);
                double newTotal = price * newQuantity;

                selectedRow.Cells[2].Value = newQuantity;
                selectedRow.Cells[3].Value = newTotal;

                double newSubTotal = 0;
                foreach (DataGridViewRow row in dgvMenuGridView.Rows)
                {
                    if (row.Cells[3].Value != null)
                    {
                        newSubTotal += Convert.ToDouble(row.Cells[3].Value);
                    }
                }

                subTotal = newSubTotal;
                txtSubTotal.Text = subTotal.ToString();
                double final = subTotal * vat;
                txtTotal.Text = final.ToString();

                txtUpdateQuan.Visible = false;
                btnsaveQuan.Visible = false;
                txtUpdateQuan.Clear();
            }

            public int GetMenuStockByItemID(string itemID)
            {
                string sql = "SELECT Stock FROM Menu WHERE ItemID = '" + itemID + "'";
                DataTable dt = new DataTable();

                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    da.Fill(dt);
                }

                if (dt.Rows.Count > 0)
                    return Convert.ToInt32(dt.Rows[0]["Stock"]);
                else
                    return 0;
            }

            private void btnConfirm_Click(object sender, EventArgs e)
            {
                string sql = "SELECT * FROM RestaurantOrder";
                DataTable dtOrders = new DataTable();

                using (SqlConnection con = new SqlConnection(connectionString))
                using (SqlCommand cmd = new SqlCommand(sql, con))
                using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                {
                    da.Fill(dtOrders);
                }

                int totalRows = dtOrders.Rows.Count;
                string OrderID = "O-" + (totalRows + 1).ToString("D3");
                string dateString = DateTime.Today.ToString("yyyy-MM-dd");

                string sqlInsertOrder = "INSERT INTO RestaurantOrder (OrderID, Date, Total) VALUES ('" + OrderID + "', '" + dateString + "', " + this.txtTotal.Text + ")";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlCommand cmdInsertOrder = new SqlCommand(sqlInsertOrder, con))
                    {
                        int cnt = cmdInsertOrder.ExecuteNonQuery();
                        if (cnt == 1)
                        {
                            foreach (DataGridViewRow row in dgvMenuGridView.Rows)
                            {
                                if (row.IsNewRow) continue;

                                if (row.Cells[4].Value != null && row.Cells[2].Value != null)
                                {
                                    string itemID = row.Cells[4].Value.ToString();
                                    int quantity = Convert.ToInt32(row.Cells[2].Value);

                                    int finalquant = GetMenuStockByItemID(itemID);
                                    int updatequantity = finalquant - quantity;
                                    if (updatequantity < 0)
                                        updatequantity = 0;

                                    string sqlUpdateMenu = "UPDATE Menu SET Stock = '" + updatequantity + "' WHERE ItemID = '" + itemID + "'";

                                    using (SqlCommand cmdUpdateMenu = new SqlCommand(sqlUpdateMenu, con))
                                    {
                                        cmdUpdateMenu.ExecuteNonQuery();
                                    }
                                }
                            }
                            this.Hide();
                            Form formMenu = new MenuList();
                            formMenu.Show();
                        }
                        else
                        {
                            MessageBox.Show("Something Error");
                        }
                    }
                }
            }
        }

    }

