﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantManagementSystems
{
    public partial class Cashier : Form
    {
        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public Cashier()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form cashier = new MenuList();
            cashier.Show();
            this.Hide();
        }

        private void Cashier_Load(object sender, EventArgs e)
        {
            LoadOrders();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            Form login = new Login();
            login.Show();
            this.Hide();
        }

        private void LoadOrders()
        {
            string sql = "SELECT OrderID as OrderId, Date, Total, Status FROM RestaurantOrder ORDER BY OrderID DESC";

            DataTable dtOrders = new DataTable();

            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand cmd = new SqlCommand(sql, con))
            using (SqlDataAdapter da = new SqlDataAdapter(cmd))
            {
                da.Fill(dtOrders);
            }

            dataGridView1.DataSource = dtOrders;
        }

        private void btnCompleted_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select at least one order to mark as Completed.");
                return;
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();

                foreach (DataGridViewRow row in dataGridView1.SelectedRows)
                {
                    if (row.Cells["OrderId"].Value == null) continue;

                    string orderId = row.Cells["OrderId"].Value.ToString();
                    string sqlUpdate = "UPDATE RestaurantOrder SET Status = 'Completed' WHERE OrderID = '" + orderId + "'";

                    using (SqlCommand cmd = new SqlCommand(sqlUpdate, con))
                    {
                        cmd.ExecuteNonQuery();
                    }
                }
            }

            MessageBox.Show("Selected order(s) marked as Completed.");

            LoadOrders(); 
        }

    }
}
