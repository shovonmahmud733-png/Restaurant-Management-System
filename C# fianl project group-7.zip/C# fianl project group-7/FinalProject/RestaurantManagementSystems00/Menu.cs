﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class MENU : Form
    {
       
        
            private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

            public MENU()
            {
                InitializeComponent();
            }

            private DataTable ExecuteQuery(string sql)
            {
                DataTable dt = new DataTable();
                try
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, con))
                        {
                            using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                            {
                                adapter.Fill(dt);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error retrieving data: " + ex.Message);
                }
                return dt;
            }

            private int ExecuteDMLQuery(string sql)
            {
                int result = 0;
                try
                {
                    using (SqlConnection con = new SqlConnection(connectionString))
                    {
                        con.Open();
                        using (SqlCommand cmd = new SqlCommand(sql, con))
                        {
                            result = cmd.ExecuteNonQuery();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database operation failed: " + ex.Message);
                }
                return result;
            }

            private void PopulateGridView(string sql = "SELECT * FROM [Menu]")
            {
                DataTable dt = ExecuteQuery(sql);
                this.dgvMenuGridView.AutoGenerateColumns = false;
                this.dgvMenuGridView.DataSource = dt;
            }

            private void ShowDetails()
            {
                PopulateGridView();
            }

            private void Menu_Load(object sender, EventArgs e)
            {
                ShowDetails();
            }

            private void btnShowDetails_Click(object sender, EventArgs e)
            {
                ShowDetails();
            }

            private void btnADD_Click(object sender, EventArgs e)
            {
                Form formadd = new AddMenu();
                formadd.Show();
            }

            private void btnUpdate_Click(object sender, EventArgs e)
            {
                if (this.dgvMenuGridView.SelectedRows.Count <= 0)
                {
                    MessageBox.Show("Please Select a Row First!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                    return;
                }

                string id = this.dgvMenuGridView.CurrentRow.Cells[0].Value.ToString();
                string name = this.dgvMenuGridView.CurrentRow.Cells[1].Value.ToString();
                string price = this.dgvMenuGridView.CurrentRow.Cells[2].Value.ToString();
                string quantity = this.dgvMenuGridView.CurrentRow.Cells[3].Value.ToString();

                Form formupdate = new UpdateMenu(id, name, price, quantity);
                formupdate.Show();
            }

            private void btnDelete_Click(object sender, EventArgs e)
            {
                DialogResult result = MessageBox.Show("Are You Sure You Want To Delete this Product", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

                if (result == DialogResult.No)
                    return;

                string id = this.dgvMenuGridView.CurrentRow.Cells[0].Value.ToString();
                string sql = "DELETE FROM [Menu] WHERE ItemID = '" + id + "';";
                int cnt = ExecuteDMLQuery(sql);

                if (cnt == 1)
                    MessageBox.Show("Product Deleted");
                else
                    MessageBox.Show("Something Error");

                PopulateGridView();
            }

            private void dgvMenuGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
            {
                
            }

            private void btnBack_Click(object sender, EventArgs e)
            {
                this.Hide();
                Admin adminForm = new Admin();
                adminForm.Show();
            }
        }
    }
