﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class UpdateProduct : Form
    {

        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public UpdateProduct()
        {
            InitializeComponent();
        }

        public UpdateProduct(string itemid, string itemname, string quan) : this()
        {
            this.txtitemID.Text = itemid;
            this.txtItemName.Text = itemname;
            this.txtStock.Text = quan;
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                string sql = "UPDATE ProductList SET Stock = '" + this.txtStock.Text +
                             "', ItemName = '" + this.txtItemName.Text +
                             "' WHERE ItemID = '" + this.txtitemID.Text + "'";

                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(sql, con))
                    {
                        int cnt = cmd.ExecuteNonQuery();
                        if (cnt == 1)
                            MessageBox.Show("Product Updated");
                        else
                            MessageBox.Show("Product Not Updated");
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Error while updating product");
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
    
}
