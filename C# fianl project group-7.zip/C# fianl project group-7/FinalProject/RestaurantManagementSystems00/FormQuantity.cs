﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantManagementSystems
{
    public partial class FormQuantity : Form
    {
        public string id;
        public string name;
        public float price;
        public Cart cart;
        public FormQuantity()
        {
            InitializeComponent();
          
            
        }
        public FormQuantity(string id,string name,float price,Cart cart)
        {
            
            InitializeComponent();
            this.id = id;
            this.name = name;
            this.price = price;
            this.cart = cart;
        }




        private void btnEnter_Click(object sender, EventArgs e)
        {
            int quan = Convert.ToInt32(this.txtQuan.Text);

            if (!cart.Visible)
            {
                cart.Show();
            }
            cart.Addincart(id, name, price, quan);
            this.Hide();  
        }

    }
}
