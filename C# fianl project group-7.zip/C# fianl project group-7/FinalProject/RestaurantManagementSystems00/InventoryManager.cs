﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantManagementSystems
{
    public partial class InventoryManager : Form
    {

        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public InventoryManager()
        {
            InitializeComponent();
        }

        private void InventoryManager_Load(object sender, EventArgs e)
        {
            LoadProducts();
        }

        private void LoadProducts(string filterItemID = "")
        {
            string sql = "SELECT ItemID, ItemName, Stock FROM ProductList";

            if (!string.IsNullOrEmpty(filterItemID))
            {
                sql += " WHERE CAST(ItemID AS VARCHAR) LIKE '" + filterItemID + "%'";
            }

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);
                        dgvProductListGridView.DataSource = dt;
                    }
                }
            }
        }

        private void btnProduct_Click(object sender, EventArgs e)
        {
            Form productForm = new Product();
            productForm.Show();
            this.Hide();
        }

        private void txtSearchByID_TextChanged(object sender, EventArgs e)
        {
            string filterText = txtSearchByID.Text.Trim();
            LoadProducts(filterText);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            this.Close();
            Login login = new Login();
            login.Show();
        }
    }
}
