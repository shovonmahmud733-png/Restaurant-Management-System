﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class Product : Form
    {
       

        private string category = "Default";
        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public Product()
        {
            InitializeComponent();
        }

        public Product(string category) : this()
        {
            this.category = category;
        }

        private void PopulateGridView(string sql = "SELECT * FROM ProductList")
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlDataAdapter sda = new SqlDataAdapter(sql, con))
            {
                DataSet ds = new DataSet();
                sda.Fill(ds);
                dgvProductListGridView.AutoGenerateColumns = false;
                dgvProductListGridView.DataSource = ds.Tables[0];
            }
        }

        private void ShowDetails()
        {
            PopulateGridView();
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            ShowDetails();
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            Form formadd = new AddProduct();
            formadd.Show();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvProductListGridView.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Please Select a Row First!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }
            var id = dgvProductListGridView.CurrentRow.Cells[0].Value.ToString();
            var name = dgvProductListGridView.CurrentRow.Cells[1].Value.ToString();
            var quan = dgvProductListGridView.CurrentRow.Cells[2].Value.ToString();

            Form formupdate = new UpdateProduct(id, name, quan);
            formupdate.Show();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dgvProductListGridView.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Please Select a Row First!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            DialogResult result = MessageBox.Show("Are You Sure You Want To Delete this Product", "Alert", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (result == DialogResult.No)
                return;

            var id = dgvProductListGridView.CurrentRow.Cells[0].Value.ToString();
            string sql = $"DELETE FROM ProductList WHERE ItemID = '{id}';";

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    int cnt = cmd.ExecuteNonQuery();
                    if (cnt == 1)
                        MessageBox.Show("Product Deleted");
                    else
                        MessageBox.Show("Something went wrong");
                }
            }
            PopulateGridView();
        }

      

        private void btnback_Click_1(object sender, EventArgs e)
        {
            this.Close();
            if (category == "Admin")
            {
                Admin admin = new Admin();
                admin.Show();
            }
            else
            {
                InventoryManager inventoryManager = new InventoryManager();
                inventoryManager.Show();
            }
        }

        private void Product_Load(object sender, EventArgs e)
        {
            PopulateGridView();
        }
    }
}
