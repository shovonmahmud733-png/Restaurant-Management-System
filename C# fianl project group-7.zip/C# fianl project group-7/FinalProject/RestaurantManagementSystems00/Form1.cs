﻿using System;

using System.Collections.Generic;

using System.ComponentModel;

using System.Data;
using System.Data.SqlClient;
using System.Drawing;

using System.Linq;

using System.Text;

using System.Threading.Tasks;

using System.Windows.Forms;



namespace RestaurantManagementSystems

{

    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";
            SqlConnection conn = new SqlConnection(connectionString);

            conn.Open();
            string sql = "SELECT * FROM [User] WHERE UserID = '" + txtUserID.Text + "' AND Password = '" + txtPassword.Text + "'";
            SqlCommand cmd = new SqlCommand(sql, conn);
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adapter.Fill(ds);

            if (ds.Tables[0].Rows.Count == 1)
            {
                string userId = ds.Tables[0].Rows[0]["UserID"].ToString();
                string role = ds.Tables[0].Rows[0]["Role"].ToString().ToLower();

                if (role == "admin")
                {
                    MessageBox.Show("Welcome Admin");
                    //Admin adminForm = new Admin(userId, role);
                    Admin adminForm=new Admin();
                    adminForm.Show();
                    this.Hide();
                }
                else if (role == "cashier")
                {
                    MessageBox.Show("Welcome Cashier");
                    //Cashier cashierForm = new Cashier(userId, role);
                    Cashier cashierForm=new Cashier();
                    cashierForm.Show();
                    this.Hide();
                }
                else if (role == "inventory manager")
                {
                    MessageBox.Show("Welcome Inventory Manager");
                    //InventoryManager inventoryForm = new InventoryManager(userId, role);
                    InventoryManager inventoryForm = new InventoryManager();
                    inventoryForm.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Unknown Role for this user.");
                }
            }
            else
            {
                MessageBox.Show("Invalid User Id & Password", "Warning!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            conn.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtUserID.Text = "";
            txtPassword.Text = "";
        }
    }



}



