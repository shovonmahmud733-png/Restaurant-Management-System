﻿using RestaurantManagementSystems;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
    public partial class MenuList : Form
    {
      

        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";
        public Cart cart;

        public MenuList()
        {
            InitializeComponent();
            cart = new Cart();
        }

        private void PopulateGridView(string sql = "SELECT * FROM Menu")
        {
            DataTable dt = new DataTable();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                using (SqlCommand cmd = new SqlCommand(sql, con))
                {
                    using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
                    {
                        sda.Fill(dt);
                    }
                }
            }

            dgvMenuGridView.AutoGenerateColumns = false;
            dgvMenuGridView.DataSource = dt;
        }

        private void ShowDetails()
        {
            PopulateGridView();
        }

        private void MenuList_Load(object sender, EventArgs e)
        {
            ShowDetails();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ShowDetails();
        }

        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            if (dgvMenuGridView.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Please Select a Row First!", "Alert", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                return;
            }

            var currentRow = dgvMenuGridView.CurrentRow;
            var id = currentRow.Cells[0].Value.ToString();
            var name = currentRow.Cells[1].Value.ToString();
            float price = Convert.ToSingle(currentRow.Cells[2].Value);

            FormQuantity quantityForm = new FormQuantity(id, name, price, cart);
            quantityForm.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Cashier cashier = new Cashier();
            cashier.Show();
        }
    }


}

