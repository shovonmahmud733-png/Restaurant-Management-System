﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace RestaurantManagementSystems
{
   
    public partial class AdminAddUsers : Form
    {
        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public AdminAddUsers()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtUserID.Text) || string.IsNullOrEmpty(txtPassword.Text) || string.IsNullOrEmpty(txtRole.Text))
            {
                MessageBox.Show("Please select all fields");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();

                    string sql = "INSERT INTO [User] (UserID, Password, Role) VALUES (@UserID, @Password, @Role)";
                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@UserID", txtUserID.Text);
                        cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                        cmd.Parameters.AddWithValue("@Role", txtRole.Text);

                        int cnt = cmd.ExecuteNonQuery();
                        if (cnt == 1)
                        {
                            MessageBox.Show("User Added");
                            txtUserID.Text = "";
                            txtPassword.Text = "";
                            txtRole.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("Something Error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

       

        private void btnClear_Click(object sender, EventArgs e)
        {
            this.Close();
            //Admin admin = new Admin();
            //admin.Show();
        }
    }
}
