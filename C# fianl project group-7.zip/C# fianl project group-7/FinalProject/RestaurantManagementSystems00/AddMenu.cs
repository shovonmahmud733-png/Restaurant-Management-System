﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RestaurantManagementSystems
{
    public partial class AddMenu : Form
    {

        

        private readonly string connectionString = @"Data Source=MSI\SQLEXPRESS;Initial Catalog=ResturentManagementSystem;Integrated Security=True;";

        public AddMenu()
        {
            InitializeComponent();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txtItemid.Text) || string.IsNullOrEmpty(txtname.Text) || string.IsNullOrEmpty(txtPrice.Text) || string.IsNullOrEmpty(txtCash.Text))
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    string sql = "INSERT INTO [Menu] (ItemID, ItemName, Price, Stock) VALUES (@itemId, @itemName, @price, @stock)";

                    using (SqlCommand cmd = new SqlCommand(sql, conn))
                    {
                        cmd.Parameters.AddWithValue("@itemId", txtItemid.Text);
                        cmd.Parameters.AddWithValue("@itemName", txtname.Text);
                        cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                        cmd.Parameters.AddWithValue("@stock", txtCash.Text);

                        int cnt = cmd.ExecuteNonQuery();
                        if (cnt == 1)
                        {
                            MessageBox.Show("Item Added");
                            txtItemid.Text = "";
                            txtname.Text = "";
                            txtPrice.Text = "";
                            txtCash.Text = "";
                        }
                        else
                        {
                            MessageBox.Show("Something Error");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }


    }
}
